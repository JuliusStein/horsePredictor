

public interface Command
{
   
    public void run();
    
    
}