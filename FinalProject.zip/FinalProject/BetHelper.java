import java.util.*;
import java.io.*;
import javax.swing.*;
public class BetHelper{
    public Race currentRace;
    
    public BetHelper(Race r){
        currentRace = r;
        
    }
    
}